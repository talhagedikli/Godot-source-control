# Get started with the Tool Mode in Godot 3

This is the result from a collaboration with [ GameFromScratch ](http://www.gamefromscratch.com/).

1. [ Introduction to the Tool mode and EditorScript ](https://youtu.be/XPs-HGzElTg) by [ Mike ](https://twitter.com/gamefromscratch)
1. [ Drawing in the viewport with the Tool mode ](https://youtu.be/QHCdeBzdmlA) by GDquest
