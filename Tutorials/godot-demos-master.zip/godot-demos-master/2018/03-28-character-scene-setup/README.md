# Create a character scene tutorial

This project is the source for the [Create a Base Character Scene in Godot 3](https://youtu.be/PKGOWGw3blw) tutorial.

The video shows how to set up a base `Character` scene and have a `Player` and a `NonPlayableCharacter` that inherits from it. This setup isn't necessary in every project, but scene inheritance is a powerful feature that's worth looking at.
