Camera fix example by Lars Kokemohr, dean of engineering at the school4games Berlin
http://school4games.net/
